from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, date
import cycle_engine


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class StatusCheckCreate(BaseModel):
    client_name: str

class PredictRequest(BaseModel):
    obs_dates: List[str]  # ISO date strings
    target_date: str  # ISO date string
    certain_dates: Optional[List[str]] = None
    auto_fill_clusters: bool = True
    max_L_fill: int = 7

class PredictResponse(BaseModel):
    cats: dict
    reliability: float
    reliability_pct: float
    reliability_color: str
    t0: Optional[str]
    used_obs: List[str]

class SuggestFillsRequest(BaseModel):
    obs_dates: List[str]
    max_L: int = 7

class SuggestFillsResponse(BaseModel):
    suggested_dates: List[str]

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Pro Ovulation Soccer API"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    _ = await db.status_checks.insert_one(status_obj.dict())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**status_check) for status_check in status_checks]

# Cycle Engine Endpoints
@api_router.post("/predict", response_model=PredictResponse)
async def predict(request: PredictRequest):
    """
    Obtiene la predicción para una fecha objetivo usando el motor bayesiano.
    """
    try:
        obs_dates = [date.fromisoformat(d) for d in request.obs_dates]
        target = date.fromisoformat(request.target_date)
        certain_dates = [date.fromisoformat(d) for d in request.certain_dates] if request.certain_dates else None
        
        result = cycle_engine.score_for_target(
            obs_dates=obs_dates,
            target_date=target,
            certain_dates=certain_dates,
            auto_fill_clusters=request.auto_fill_clusters,
            max_L_fill=request.max_L_fill
        )
        
        if result is None:
            raise HTTPException(status_code=400, detail="No se pudo calcular la predicción")
        
        # Convertir dates a ISO strings
        result['t0'] = result['t0'].isoformat() if result['t0'] else None
        result['used_obs'] = [d.isoformat() for d in result['used_obs']]
        
        return PredictResponse(**result)
    except Exception as e:
        logger.error(f"Error en predict: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/suggest-fills", response_model=SuggestFillsResponse)
async def suggest_fills(request: SuggestFillsRequest):
    """
    Obtiene sugerencias de fechas intermedias para rellenar clústeres.
    """
    try:
        obs_dates = [date.fromisoformat(d) for d in request.obs_dates]
        suggested = cycle_engine.get_suggested_cluster_fills(obs_dates, max_L=request.max_L)
        
        return SuggestFillsResponse(
            suggested_dates=[d.isoformat() for d in suggested]
        )
    except Exception as e:
        logger.error(f"Error en suggest_fills: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
