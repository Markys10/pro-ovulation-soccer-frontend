# demo_fill_and_predict.py
from datetime import date
import cycle_engine, database

def demo():
    database.init_db()
    pid = 1
    # test: add sparse bleeds
    database.add_bleed(pid, "2025-08-17", certain=1)
    database.add_bleed(pid, "2025-08-21", certain=1)
    bleeds = [d for d,c in database.get_bleeds(pid)]
    print("Bleeds before fill:", bleeds)
    suggested = cycle_engine.get_suggested_cluster_fills(bleeds, max_L=7)
    print("Suggested fills:", suggested)
    filled = cycle_engine.apply_cluster_fill(bleeds, max_L=7)
    print("Filled bleeds:", filled)
    target = date(2025,8,18)
    res = cycle_engine.score_for_target(filled, target, certain_dates=filled)
    print("Prediction for", target, "->", res)

if __name__ == "__main__":
    demo()
