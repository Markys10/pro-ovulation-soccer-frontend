# cycle_engine.py
"""
Complete Bayesian cycle engine (advanced version) for POS_app.
Features:
- Priors over cycle lengths K and bleed durations L
- Likelihood model treating recorded sangrado dates as observations
- Cluster detection + automatic expansion of intermediate bleed days (suggestion + apply)
- Posterior marginalization over K,L,r
- Desire curve interpolation from 28-day template to arbitrary K
- Exclusive categorization: regla > perrisima > horny > nifunifa
- Reliability metric: 1 - normalized Shannon entropy (0..1)
- Convenience fields: sexual_prob, dominance_gap, dominant_sex
"""

from datetime import date, timedelta
import math

# ---------------------------
# Priors (adjustable)
# ---------------------------
P_K = {26:0.10,27:0.12,28:0.30,29:0.20,30:0.15,31:0.08,32:0.05}
P_L = {2:0.05,3:0.30,4:0.35,5:0.20,6:0.07,7:0.03}

# Base 28-day libido template (days 1..28)
BASE_28 = {
 1:0.05,2:0.05,3:0.05,4:0.05,5:0.05,6:0.05,
 7:0.12,8:0.18,9:0.26,10:0.34,11:0.44,12:0.55,
 13:0.64,14:0.70,15:0.63,16:0.52,17:0.40
}
_start = 0.22; _end = 0.12
for i, day in enumerate(range(18,29)):
    BASE_28[day] = _start + (_end - _start) * (i / (28-18))

# thresholds
T_PERRISIMA = 0.75
T_HORNY = 0.40

# likelihood constants
P_BLEED = 0.95
P_FALSE = 0.05

# reliability thresholds (pct)
RELIABILITY_THRESHOLDS = {'green':75.0, 'yellow':50.0, 'red':0.0}

# ---------------------------
# Interpolate base curve to K days
# ---------------------------
def interp_curve(K):
    old_x = [i/(27) for i in range(28)]
    old_y = [BASE_28[i+1] for i in range(28)]
    new_x = [i/(K-1) if K>1 else 0 for i in range(K)]
    sK = []
    for nx in new_x:
        if nx <= old_x[0]:
            s = old_y[0]
        elif nx >= old_x[-1]:
            s = old_y[-1]
        else:
            for j in range(len(old_x)-1):
                if old_x[j] <= nx <= old_x[j+1]:
                    t = (nx - old_x[j]) / (old_x[j+1] - old_x[j])
                    s = old_y[j] + t*(old_y[j+1]-old_y[j])
                    break
        sK.append(s)
    return sK

# ---------------------------
# Likelihood of observation set given (K,L,r,t0)
# ---------------------------
def likelihood(obs_dates, K, L, r, t0):
    prod = 1.0
    for t in obs_dates:
        d = (t - t0).days
        cd = ((r + d - 1) % K) + 1
        if 1 <= cd <= L:
            prod *= P_BLEED
        else:
            prod *= P_FALSE
    return prod

# ---------------------------
# Cluster detection and expansion (suggestions)
# ---------------------------
def get_suggested_cluster_fills(obs_dates, max_L=7):
    """
    Given a list of observed bleed dates (date or iso strings), detect clusters
    where consecutive observations are within max_L-1 days, and propose filling
    the intermediate dates between the min and max of each cluster.
    Returns a sorted list of suggested dates (date objects) not already present.
    """
    if not obs_dates:
        return []
    obs = [d if isinstance(d, date) else date.fromisoformat(d) for d in obs_dates]
    obs = sorted(obs)
    clusters = []
    cur = [obs[0]]
    for d in obs[1:]:
        if (d - cur[-1]).days <= (max_L - 1):
            cur.append(d)
        else:
            clusters.append(cur)
            cur = [d]
    clusters.append(cur)
    suggested = []
    for cl in clusters:
        if len(cl) <= 1:
            continue
        start = cl[0]
        end = cl[-1]
        for i in range((end - start).days + 1):
            candidate = start + timedelta(days=i)
            if candidate not in cl:
                suggested.append(candidate)
    return sorted(set(suggested))

def apply_cluster_fill(obs_dates, max_L=7):
    """
    Expand observed bleed dates by filling interior days for clusters.
    Returns sorted list of dates including originals and fills.
    """
    if not obs_dates:
        return []
    obs = [d if isinstance(d, date) else date.fromisoformat(d) for d in obs_dates]
    obs = sorted(obs)
    clusters = []
    cur = [obs[0]]
    for d in obs[1:]:
        if (d - cur[-1]).days <= (max_L - 1):
            cur.append(d)
        else:
            clusters.append(cur)
            cur = [d]
    clusters.append(cur)
    expanded = []
    for cl in clusters:
        if len(cl) == 1:
            expanded.append(cl[0])
        else:
            start = cl[0]
            end = cl[-1]
            for i in range((end - start).days + 1):
                expanded.append(start + timedelta(days=i))
    expanded = sorted(set(expanded))
    return expanded

# ---------------------------
# Build posterior over (K,L,r)
# ---------------------------
def build_posterior(obs_dates):
    if not obs_dates:
        return [], None
    t0 = obs_dates[-1]
    rows = []
    for K, pk in P_K.items():
        sK = interp_curve(K)
        for L, pl in P_L.items():
            for r in range(1, L+1):
                prior = pk * pl * (1.0 / L)
                like = likelihood(obs_dates, K, L, r, t0)
                w = prior * like
                rows.append({'K':K,'L':L,'r':r,'w':w,'sK':sK})
    total = sum(x['w'] for x in rows)
    if total <= 0:
        n = len(rows)
        for x in rows:
            x['w_norm'] = 1.0/n
    else:
        for x in rows:
            x['w_norm'] = x['w']/total
    return rows, t0

# ---------------------------
# Reliability metric (entropy-based)
# ---------------------------
def compute_reliability(cats):
    probs = [max(0.0, float(cats.get(k, 0.0))) for k in ['regla','perrisima','horny','nifunifa']]
    s = sum(probs)
    if s <= 0:
        reliability = 0.0
    else:
        probs = [p/s for p in probs]
        H = 0.0
        for p in probs:
            if p > 0:
                H -= p * math.log2(p)
        max_H = math.log2(4)
        H_norm = H / max_H if max_H > 0 else 1.0
        reliability = max(0.0, 1.0 - H_norm)
    pct = reliability * 100.0
    if pct >= RELIABILITY_THRESHOLDS['green']:
        color = 'green'
    elif pct >= RELIABILITY_THRESHOLDS['yellow']:
        color = 'yellow'
    else:
        color = 'red'
    return reliability, round(pct,1), color

# ---------------------------
# Main scoring API
# ---------------------------
def score_for_target(obs_dates, target_date, certain_dates=None, auto_fill_clusters=True, max_L_fill=7):
    """
    obs_dates: list[date] or ISO strings
    target_date: date object
    certain_dates: optional list/set of date or ISO strings the caller marks as absolute certainties
    auto_fill_clusters: if True, expands clusters using apply_cluster_fill
    Returns dict:
      {
        'cats': {'regla':..., 'perrisima':..., 'horny':..., 'nifunifa':...},
        'reliability': 0..1,
        'reliability_pct': 0..100,
        'reliability_color': 'green'|'yellow'|'red',
        't0': reference date,
        'used_obs': [dates used]
      }
    """
    obs_dates = [d if isinstance(d, date) else date.fromisoformat(d) for d in (obs_dates or [])]
    obs_dates = sorted(obs_dates)
    certain_dates = set([d if isinstance(d, date) else date.fromisoformat(d) for d in (certain_dates or [])])

    if auto_fill_clusters:
        used_obs = apply_cluster_fill(obs_dates, max_L=max_L_fill)
    else:
        used_obs = obs_dates

    if not used_obs:
        return None

    # if target explicitly marked certain -> return certainty immediately
    if target_date in certain_dates:
        cats = {'regla':1.0, 'perrisima':0.0, 'horny':0.0, 'nifunifa':0.0}
        reliability, pct, color = compute_reliability(cats)
        return {'cats':cats, 'reliability':reliability, 'reliability_pct':pct, 'reliability_color':color, 't0': used_obs[-1] if used_obs else None, 'used_obs': used_obs}

    rows, t0 = build_posterior(used_obs)
    if t0 is None:
        return None

    d = (target_date - t0).days
    cats = {'regla':0.0,'perrisima':0.0,'horny':0.0,'nifunifa':0.0}
    for r in rows:
        K = r['K']; L = r['L']; rr = r['r']; w = r['w_norm']; sK = r['sK']
        cd = ((rr + d - 1) % K) + 1
        desire = sK[cd-1]
        if 1 <= cd <= L:
            cats['regla'] += w
        else:
            if desire >= T_PERRISIMA:
                cats['perrisima'] += w
            elif desire >= T_HORNY:
                cats['horny'] += w
            else:
                cats['nifunifa'] += w
    s = sum(cats.values())
    if s > 0:
        for k in cats:
            cats[k] = cats[k] / s
    else:
        cats = {k: 0.25 for k in cats}
    reliability, pct, color = compute_reliability(cats)
    cats_rounded = {k: round(v,4) for k, v in cats.items()}
    cats_rounded['sexual_prob'] = round(cats_rounded.get('horny',0) + cats_rounded.get('perrisima',0),4)
    sorted_vals = sorted([(v,k) for k,v in cats_rounded.items() if k in ['regla','perrisima','horny','nifunifa']], reverse=True)
    p_max, top_cat = sorted_vals[0]
    p2 = sorted_vals[1][0]
    cats_rounded['dominance_gap'] = round(p_max - p2,4)
    if cats_rounded['sexual_prob'] > max(cats_rounded['regla'], cats_rounded['nifunifa']):
        cats_rounded['dominant_sex'] = 'perrisima' if cats_rounded['perrisima'] >= cats_rounded['horny'] else 'horny'
    else:
        cats_rounded['dominant_sex'] = None
    return {'cats':cats_rounded, 'reliability':round(reliability,4), 'reliability_pct':pct, 'reliability_color':color, 't0': t0, 'used_obs': used_obs}

# Demo runner (only when executed directly)
if __name__ == "__main__":
    # quick test scenario
    obs = [date(2025,8,17)]
    target = date(2025,11,14)
    print("Suggested fills:", get_suggested_cluster_fills(obs))
    print("Score:", score_for_target(obs, target))
