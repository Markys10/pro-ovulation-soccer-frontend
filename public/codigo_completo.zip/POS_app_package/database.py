# database.py -- sqlite helpers for POS_app integration
import sqlite3
from datetime import date

DB_PATH = "pos.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS profiles (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT
                 )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bleeds (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 profile_id INTEGER,
                 bleed_date TEXT,
                 certain INTEGER DEFAULT 0
                 )""")
    conn.commit()
    conn.close()

def add_bleed(profile_id, iso_date, certain=1):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO bleeds (profile_id, bleed_date, certain) VALUES (?, ?, ?)", (profile_id, iso_date, int(certain)))
    conn.commit()
    conn.close()

def get_bleeds(profile_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT bleed_date, certain FROM bleeds WHERE profile_id = ? ORDER BY bleed_date ASC", (profile_id,))
    rows = c.fetchall()
    conn.close()
    return [(date.fromisoformat(r[0]), bool(r[1])) for r in rows]

def set_certain(profile_id, iso_date):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE bleeds SET certain = 1 WHERE profile_id = ? AND bleed_date = ?", (profile_id, iso_date))
    conn.commit()
    conn.close()
